#!/bin/sh

python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c1_maria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c2_maria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c3_maria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c4_maria_2/
