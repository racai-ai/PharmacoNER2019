#!/bin/sh

python evaluate.py ner gold/subtrack1/radu_dev_3/ system/subtrack1/baseline_radu_3/
