#!/bin/sh

python evaluate.py ner gold/subtrack1/dev/ system/subtrack1/baseline/
