#!/bin/sh

python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/combineb2_radu_2/
