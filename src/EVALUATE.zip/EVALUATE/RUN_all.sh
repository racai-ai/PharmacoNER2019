#!/bin/sh

echo "RACAI-C4"
python evaluate.py ner RUN/test/subtrack1/ /data/vasile/spanish/RUN/AlreadySubmitted/racai-c4/subtask1/

echo "RACAI-C1"
python evaluate.py ner RUN/test/subtrack1/ /data/vasile/spanish/RUN/AlreadySubmitted/racai-c1/subtask1/

echo "RACAI-bl"
python evaluate.py ner RUN/test/subtrack1/ /data/vasile/spanish/RUN/AlreadySubmitted/racai-bl/subtask1/

echo "RACAI-rpcn"
python evaluate.py ner RUN/test/subtrack1/ /data/vasile/spanish/RUN/AlreadySubmitted/racai-rpcn/subtask1/

echo "RACAI-c4m"
python evaluate.py ner RUN/test/subtrack1/ /data/vasile/spanish/RUN/AlreadySubmitted/racai-c4m/subtask1/

