#!/bin/sh

python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c1_c1_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c2_c1_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c3_c1_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c4_c1_brmaria_2/

python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c1_c2_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c2_c2_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c3_c2_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c4_c2_brmaria_2/

python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c1_c3_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c2_c3_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c3_c3_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c4_c3_brmaria_2/

python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c1_c3_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c2_c3_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c3_c3_brmaria_2/
python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/c4_c3_brmaria_2/
