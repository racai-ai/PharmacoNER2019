#!/bin/sh

python evaluate.py ner gold/subtrack1/radu_dev_3/ system/subtrack1/c1_radu_3/
python evaluate.py ner gold/subtrack1/radu_dev_3/ system/subtrack1/c2_radu_3/
python evaluate.py ner gold/subtrack1/radu_dev_3/ system/subtrack1/c3_radu_3/
python evaluate.py ner gold/subtrack1/radu_dev_3/ system/subtrack1/c4_radu_3/
python evaluate.py ner gold/subtrack1/radu_dev_3/ system/subtrack1/c5_radu_3/
