#!/bin/sh

python evaluate.py ner gold/subtrack1/radu_dev_2/ system/subtrack1/combine44_radu_2/
